#include <iostream>
#include <string>

class BusTicket {
    static int issued; // shared by all BusTicket objects
    static const int CAPACITY = 3;
    int seat;
    std::string name;

public:
    explicit BusTicket(const std::string& n) : seat(0), name(n)
    {
        if (issued < CAPACITY) {   // TODO 1
            ++issued;
            seat = issued;
        }
    }

    static int count()
    {
        return issued;             // TODO 2
    }

    void print() const
    {
        std::cout << name << ": "
                  << (seat ? "Seat " + std::to_string(seat) : std::string("Waiting"))
                  << '\n';
    }
};

int BusTicket::issued = 0; // definition of the static data member

void makeTwo()
{
    BusTicket x("P"), y("Q");        // destroyed at the end of the function
    x.print(); y.print();
    std::cout << "  count inside call: " << BusTicket::count() << '\n';
}

int main()
{
    std::cout << "call 1\n"; makeTwo();
    std::cout << "call 2\n"; makeTwo();
    std::cout << "count after both calls: " << BusTicket::count() << '\n';
}

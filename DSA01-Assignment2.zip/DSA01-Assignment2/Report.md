# Assignment 2 – CO2 Report (Q1–Q7)

Name: ____________  Register No.: ____________  GitHub: https://github.com/____/DSA01-<RegNo>-Assignment2
Compiler: g++ 13.3.0, `-std=c++17 -Wall -Wextra`

> **Note on predictions.** The assignment only credits predictions written *before* running. The predictions below are worked out by hand from the C++ rules. Re-derive them yourself, write them into your own report before you run the programs, and be ready to explain them in the viva.

---

## Q1 – Call by Value, Reference and Pointer (6)

**Three versions** (`Q1/q1_three_ways.cpp`)

| Version | Signature | Stored fee after `apply(fee,10)` from 45000 |
|---|---|---|
| value | `void applyByValue(long long fee,int p)` | 45000 (predicted and observed) |
| reference | `void applyByRef(long long& fee,int p)` | 40500 |
| pointer | `void applyByPtr(long long* fee,int p)` | 34425 after 15% on 40500 |

Observed: the value version printed 40500 *inside* the function but the stored fee stayed 45000. This is the bug in the problem statement.

**Inquiry.** By value: the parameter is a new local `long long` on the callee's stack, initialised with a copy of the argument, so changes die with the function. By reference: the parameter is an alias of the caller's variable (usually implemented as a hidden address), so no new fee exists. By pointer: the parameter is a local pointer holding the caller's address; the pointer itself is a copy, but `*fee` is the caller's variable. Only reference and pointer change the caller's fee because they reach the original object. Use `const T&` for input-only parameters that are large (a `Student`): no copy (472 bytes vs 8) and no modification allowed. For a `long long`, plain by-value is as cheap as a reference.

**Design decision.** I would **return the new fee** (`long long applyConcession(long long fee,int p)`) and let the caller assign. Several concessions compose naturally: `applyReturn(applyReturn(45000,10),15)` = 34425 (verified, same as the in-place chain), the function has no side effects so it is easy to test, and the call site shows what changes. In-place by reference is better only when the object is large and the update must happen on a stored record. A pointer is needed only when "no fee" (nullptr) is meaningful.

**Predict the Output** (`q1_predict.cpp`)
- `change(a,b,&c)`: `a` is a copy (stays 1), `b` is an alias (2→12), `*c` is the caller's `c` (3→13). Line 1: `1 12 13`.
- `bigger(a,c)` returns a reference to the larger of 1 and 13, i.e. `c`; assigning 100 changes `c`. Line 2: `1 100`.
- `show(1)` uses y=5, z=10 → 16; `show(1,2)` uses z=10 → 13; `show(1,2,3)` uses no defaults → 6. Line 3: `16 13 6 ` (trailing space, then newline).

Actual output: `1 12 13` / `1 100` / `16 13 6 `. **No differences.**

**Complete the Code** (`q1_complete.cpp`): TODO 1 = `fee -= fee * percent / 100;` Output `after call by value : 45000` / `after call by reference: 40500`, as expected. By value leaves 45000 because `applyByValue` reduces its own copy, which is destroyed on return.

**Alternative and complexity.** Return version: `fee = applyConcession(fee,10);`. Time is O(1) in every version (one multiply, one divide). Space copied per call:

| Parameter | `long long` | `Student` (472 B measured with `sizeof`) |
|---|---|---|
| by value | 8 B | 472 B copied per call (O(sizeof T)) |
| by reference | ~8 B (address) | ~8 B |
| by const reference | ~8 B, read-only | ~8 B, read-only |

---

## Q2 – Return by Reference and Its Dangers (4)

(`Q2/q2_marks.cpp`, `Q2/q2_dangling.cpp`)

Marks `{56,78,91,64,88,45}`:
- `highest(marks,6) += 2;` → 91 becomes 93.
- `highest(marks,6) = 95;` → the call is an lvalue because it returns `int&`; 93 becomes 95.
- `const int& cr = highestConst(...)`: read-only view, `cr = 1;` would not compile. `int copy = highestCopy(...)`: `copy += 2` gives 97 but the array element stays 95.

**Compiler evidence for the local reference:**
```
Q2/q2_dangling.cpp:5:12: warning: reference to local variable 'local' returned [-Wreturn-local-addr]
```
Using it is undefined behaviour: `local` is destroyed when `bad()` returns, so `r` refers to dead stack storage. Observed: **Segmentation fault** (exit 139) at both -O0 and -O2. UB gives no guarantee: another compiler or flag could print 42 or garbage, which is more dangerous than a crash.

**Reference vs const reference vs copy.** `int&` gives read/write access to the original and can be used on the left of `=`; `const int&` gives read-only access without a copy; `int` returns an independent copy (safe, but changes do not reach the array). All three are safe only if the referenced object outlives the call.

**Changed condition (vector).** Observed: `capacity 3 -> 192`, and `&v[2]` before and after the pushes **differ (moved: true)**. When a vector exceeds its capacity it allocates a new block, moves the elements and frees the old block, so a reference/pointer/iterator taken earlier points to freed memory. An index stays valid (`v[2] = 91` after growth).

**Alternative and complexity.** Index: `marks[highestIndex(marks,6)] += 2;`. Pointer: `*highestPtr(marks,6) += 2;` (and must check for nullptr on empty input). Time to find the highest: one pass, O(n) for all three. Space: O(1) for all three. Safety with a growing vector: index is safe (just re-index), reference and pointer are invalidated by reallocation.

---

## Q3 – Default Arguments and Overloading (6)

(`Q3/q3_ambiguous.cpp`, `q3_long_ambiguous.cpp`, `q3_charge.cpp`)

**The error** (observed):
```
error: call of overloaded 'charge(double)' is ambiguous
   candidate: 'double charge(double)'
   candidate: 'double charge(double, bool, bool)'
error: call of overloaded 'charge(double, bool)' is ambiguous
   candidate: 'double charge(double, bool)'
   candidate: 'double charge(double, bool, bool)'
```
`charge(5.0)` matches `charge(double)` and the three-parameter version with both defaults, both exact matches, so neither is better. The same holds for `charge(5.0,true)`. The default arguments make the three-parameter version cover every call the other two cover.

**Redesign**
```cpp
double charge(double kg, bool express=false, bool insured=false); // weight in kg
double charge(int grams, bool express=false, bool insured=false); // weight in grams
double charge(const Parcel& p);                                   // Parcel object
```
Defaults appear once, in the declaration. There is no overlap in the first parameter, apart from the int/double pair, which is resolved by exact match.

**Predictions and observations**

| # | Call | Predicted | Observed (output) |
|---|---|---|---|
| 1 | `charge(2)` | int exact match → grams | grams, 30.04 |
| 2 | `charge(2.0f)` | float→double is a *promotion*, float→int a *conversion*; promotion wins → kg | kg, 70.00 |
| 3 | `charge(2.5)` | double exact → kg | kg, 80.00 |
| 4 | `charge(500,true)` | (int,bool) exact → grams | grams, 80.00 |
| 5 | `charge(1.5,true,true)` | kg | kg, 115.00 |
| 6 | `charge(parcel)` | Parcel | Parcel, 130.00 |

All six matched. Caution: `charge(2L)` is **ambiguous** (observed compile error): long→int and long→double are both conversions of equal rank.

**Inquiry.** Overload resolution ranks each argument conversion: (1) exact match (including reference binding, adding `const`), (2) promotion (float→double, short/char→int), (3) standard conversion (int↔double, long→int). The best function must be at least as good for every argument and strictly better for one; otherwise the call is ambiguous. Defaults must go from the right because the compiler fills in omitted arguments from the right: if `y` had a default but `z` did not, `f(1,2)` could not say which parameter is missing.

**Alternative and complexity.** A `Parcel` with optional fields (`charge(Parcel{.kg=2,.express=true})`) or `template<class W> double charge(W w, ...)`. A new option (e.g. fragile) means: overloads/defaults design needs every function updated and risks new ambiguities; a Parcel needs one new field with a default and no signature change; a template works for any numeric type but needs constraints to prevent nonsense types. Overload resolution is a compile-time activity: **zero run-time cost**, O(1) call. Space copied per call: a few scalars (≤ 8+1+1 bytes) for overloads; `Parcel` by value ≈ 16 bytes, by const reference ≈ 8.

---

## Q4 – Class with an Array Inside (6)

(`Q4/q4_shift.cpp`)

`SavingsAccount` has private `accNo`, `balance`, `Transaction txn[10]`, `count`. The constructor and `getBalance()` are defined inside the class (implicitly inline); `record`, `deposit`, `withdraw`, `miniStatement` are defined outside with `SavingsAccount::`. Test: 12 operations, so the first two are discarded; the statement shows the last 10 (oldest first, balance 4300). Observed output in `logs/all_runs.txt`.

**Inquiry.** The array is private because its invariants (0 ≤ count ≤ 10, chronological order, "older discarded") must be maintained by the class; public access would let any code write out of order or past the count, and make a later change of representation (e.g. circular buffer) break every user. The 11th transaction: *shifting* moves 9 elements left and writes at index 9, so each add after the 10th costs O(k) with k = 10 (k−1 copies); a *circular index* overwrites the oldest slot and moves `start`, O(1), at the cost of one extra `start` member and index arithmetic in `miniStatement()`.

**Design decision (50 transactions).** The shifting design changes least: change one constant (`TXN_CAP`); nothing else changes, because every loop uses `CAP`. Cost rises to ~50 copies per deposit, still small at ATM rates; the circular design needs no change either if written with `CAP`, which is why Q7 is both.

**Alternative and complexity.** `std::deque` (push_back, pop_front when size>10) or a circular buffer with `start`. Add: O(k) shifting vs O(1). Space: fixed array 10 × 16 B = 160 B (+count) in both array designs; deque is O(10) elements but with extra block/pointer overhead and heap allocation.

---

## Q5 – Static Members and Arrays of Objects (7)

(`Q5/q5_predict.cpp`, `q5_complete.cpp`, `q5_function_test.cpp`)

**Design.** The seat counter (`issued`) and the capacity belong to the class, not a ticket → `static int issued; static const int CAPACITY`. `seat` and `name` stay per-object. A static data member is only *declared* in the class; it must be **defined once outside** (`int BusTicket::issued = 0;`) in one source file, otherwise a linker error ("undefined reference"). A static member function has no `this`, so it cannot use non-static members (no object to read them from); it can use static members and be called as `BusTicket::count()` with no object. An array of objects (`BusTicket trip[4] = {BusTicket("Asha"),...}`) runs the constructor once per element in order; with no default constructor each element must be initialised explicitly. Objects created in a loop or function each run the constructor and increase the counter; destruction does **not** decrease it unless a destructor is written to do so.

**Predict the Output.** `counter[0]` → 101, `counter[1]` → 102, `counter[2]` → 103, `extra` → 104; `issued() = 104 - 100 = 4`. Predicted `101 103 104 4`. Observed `101 103 104 4`. No differences. The static starts at 100 because of the definition `int Token::next = 100;`, initialised once before `main`; the constructor ran 4 times (3 for the array + 1).

**Complete the Code.** TODO 1: `if (issued < CAPACITY) { ++issued; seat = issued; }`. TODO 2: `return issued;`. Output: `Asha: Seat 1`, `Bala: Seat 2`, `Chitra: Seat 3`, `Dev: Waiting`, `Issued: 3`, matching the expected output (4 tickets exceed capacity 3).

**Function called twice** (`q5_function_test.cpp`): call 1 issues P=Seat 1, Q=Seat 2 (count 2); call 2 issues P=Seat 3, Q=Waiting (count 3). The count stays at 3 afterwards: the counter is class-wide and is never decremented when the local tickets die.

**Alternative and complexity.** Global variable: `int issued` visible to all code (any code can corrupt it, name clashes). A `TicketOffice` object passed to each `BusTicket(name, office)`: encapsulated, and two buses work by two offices at once. Static: encapsulated but one bus per program (both buses would share the counter). Time O(1) in all; space one counter in all (plus one office reference per ticket in the office design).

---

## Q6 – Friend and Inline Functions (8)

(`Q6/q6_complete.cpp`, `q6_tests.cpp`, `q6_bench.cpp`)

**Design.** A friend function works on two objects *equally*: `minutesBetween(a,b)` is symmetric, whereas `a.minutesTo(b)` makes `a` special. A friend is a non-member: it is called as `minutesBetween(a,b)` (no `.`, no `this`), but it can access private members like a member. A member is called through an object, has `this`, and is in the class scope. `inline` is a *request* to the compiler to substitute the body at the call site (removing call overhead); the compiler may ignore it, and honours it only when optimising (GCC at -O0 does not inline). Making members public would lose encapsulation: any code could set minutes = 99 and break the invariant 0–59, and the representation could never be changed.

**Complete the Code.** TODO 1: `abs((a.h*60+a.m)-(b.h*60+b.m))` (written with a sign test). TODO 2: `a.h < b.h || (a.h == b.h && a.m < b.m)`. Output `205 false` (9:45→585 min, 13:10→790 min, diff 205; arrival is not earlier than departure) as expected.

**Correctness tests** (observed, all checked by hand):

| Pair | minutesBetween | earlier(a,b) |
|---|---|---|
| 11:50 / 12:10 | 20 | true |
| 12:10 / 11:50 | 20 | false |
| 09:45 / 09:45 | 0 | false |
| 00:00 / 23:59 | 1439 | true |
| 12:00 / 12:00 | 0 | false |

**Growth investigation** (10,000,000 calls, ms):

| Variant | -O0 | -O2 |
|---|---|---|
| friend, `inline` | 108 | 35 |
| friend, noinline | 113 | 33 |
| member `minutesTo` | 119 | 36 |
| non-friend + getters | 128 | 35 |

Explanation: at -O0 nothing is inlined (even `inline` ones), so all variants pay for real calls and getter calls (getters are slowest); `-O2` is ~3x faster for all. At -O2 the differences are within noise (the loop's `%` operations dominate): a function this small is cheap with or without inlining, and the compiler inlines small functions on its own whatever the keyword says. (Timing varies between runs; repeat 3 times and report the median.)

**Deployment decision.** For a read-only symmetric computation I keep the friend functions. Compared with member + getters, they give the same speed at -O2 and expose no extra interface; getters leak the representation to everyone. If other callers need hours/minutes anyway, getters + free functions are reasonable and the friend is not needed.

**Alternative and complexity.** Member (`a.minutesTo(b)`), or getters + free function: O(1) per call in all; measured as above; encapsulation: friend = exposes private data to two named functions only; member = to its own class only (best); getters = to everyone (weakest).

---

## Q7 – Diagnose, Redesign and Validate (13)

**Chosen program: Q4 (`SavingsAccount` with shifting array).**

### A. Diagnosis (2)
Each transaction after the buffer is full shifts CAP−1 elements, so the cost depends on the size of the window, which the requirement "last 50 transactions" (and any larger one) increases. Measured (`-O2`, 1,000,000 deposits): CAP=10 → 9.6 ns, CAP=50 → 16.0 ns, CAP=1000 → 114.4 ns per deposit. The slowdown tracks CAP, so the cause is the *physical movement of every element to keep logical order* (data order = array order).

### B. Objective (2)
Make `deposit()` cost independent of CAP: per-deposit time at CAP=1000 within 1.5× of the time at CAP=10, with identical mini-statement output.

### C. Design (4)
Keep the class interface; change the representation to a **circular buffer**: new private `int start` (index of the oldest). Add: `txn[(start+count)%CAP]` while not full; when full, overwrite `txn[start]` and `start=(start+1)%CAP`. `miniStatement()` prints `txn[(start+k)%CAP]` for k=0..count−1. Feature used: private members, member functions defined outside the class; no library facility. Extra memory: one `int` (4 B). Trade-off: indexing code is a bit more complex (modulo), and `miniStatement()` costs the same O(CAP) as before.
```
record(t,a):
  if count < CAP: txn[(start+count)%CAP] = {t,a}; count++
  else:           txn[start] = {t,a}; start = (start+1)%CAP
```
Class diagram: `SavingsAccount { -accNo, -balance, -txn[CAP], -count, -start; +deposit(), +withdraw(), +miniStatement(), +getBalance() }`. The only added member is `start`.

### D. Prediction (1)
Circular deposit time will be about constant (≈4 ns) for all CAP; the improvement grows with CAP: roughly the same at 10, 2–3× faster at 50, >20× faster at 1000.

### E. Validation (2)
Same test program, same 12 operations: the two statements are **identical** (`diff` shows no difference; same checksum of the stored transactions for every CAP). Same benchmark (1,000,000 deposits, -O2):

| CAP | Shift (ns/deposit) | Circular (ns/deposit) | Speed-up |
|---|---|---|---|
| 10 | 9.6 | 4.0 | 2.4x |
| 50 | 16.0 | 4.1 | 3.9x |
| 1000 | 114.4 | 4.1 | 28x |

### F. Defence (2)
Objective met: circular is flat (4.0 → 4.1 ns from CAP 10 to 1000, within 1.5×), the output is identical. New costs: one `start` field, modulo arithmetic and slightly harder-to-read code, so bugs at the wrap-around point are possible (tested with 12 > 10 operations). The original may still be preferable at CAP=10: it is simpler, the array is always in order (easy to copy out or print), and the 5-ns difference per deposit is irrelevant at ATM speeds. The redesign matters only when the window or the transaction rate is large.

---

## Evidence checklist for the submission
- Re-run every program yourself, take screenshots into each QX folder, and commit **at least once per task**.
- Fill the name, register number, repository link and your own predictions (written before running).
- Re-measure the timings on your machine; yours will differ.

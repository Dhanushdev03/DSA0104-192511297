#include <iostream>
#include <vector>

int& highest(int* m, int n)                   { int k = 0; for (int i = 1; i < n; ++i) if (m[i] > m[k]) k = i; return m[k]; }
const int& highestConst(const int* m, int n)  { int k = 0; for (int i = 1; i < n; ++i) if (m[i] > m[k]) k = i; return m[k]; }
int highestCopy(const int* m, int n)          { int k = 0; for (int i = 1; i < n; ++i) if (m[i] > m[k]) k = i; return m[k]; }
int highestIndex(const int* m, int n)         { int k = 0; for (int i = 1; i < n; ++i) if (m[i] > m[k]) k = i; return k; }
int* highestPtr(int* m, int n)                { return &highest(m, n); }

void print(const char* t, const int* m, int n) { std::cout << t; for (int i = 0; i < n; ++i) std::cout << ' ' << m[i]; std::cout << '\n'; }

int main()
{
    int marks[6] = {56, 78, 91, 64, 88, 45};
    print("original          :", marks, 6);

    highest(marks, 6) += 2;                       // moderation applied directly
    print("after highest()+=2:", marks, 6);

    highest(marks, 6) = 95;                       // call on the left of =
    print("after highest()=95:", marks, 6);

    const int& cr = highestConst(marks, 6);       // read-only view: cr = 1; would not compile
    int copy = highestCopy(marks, 6);
    copy += 2;                                    // changes only the copy
    std::cout << "const ref reads " << cr << ", copy modified to " << copy << ", array still " << marks[2] << '\n';

    marks[highestIndex(marks, 6)] += 1;           // index version
    *highestPtr(marks, 6) += 1;                   // pointer version
    print("after index & ptr +1 each:", marks, 6);

    // changed condition: growing vector
    std::vector<int> v{56, 78, 91};
    int* before = &v[2];
    std::size_t capBefore = v.capacity();
    for (int i = 0; i < 100; ++i) v.push_back(i);
    int* after = &v[2];
    std::cout << "vector: capacity " << capBefore << " -> " << v.capacity()
              << ", element 2 moved: " << std::boolalpha << (before != after)
              << "  (an int& taken before the growth would now dangle)\n";
    std::size_t idx = 2;                          // an index stays valid
    std::cout << "by index after growth: v[" << idx << "] = " << v[idx] << '\n';
}

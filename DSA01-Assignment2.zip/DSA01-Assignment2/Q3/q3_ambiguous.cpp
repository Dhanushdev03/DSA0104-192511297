#include <iostream>
double charge(double weight)                              { return weight; }
double charge(double weight, bool express)                { return weight + express; }
double charge(double weight, bool express = false, bool insured = false) { return weight + express + insured; }
int main()
{
    std::cout << charge(5.0) << '\n';          // ambiguous: (double) and (double,bool=false,bool=false)
    std::cout << charge(5.0, true) << '\n';    // ambiguous: (double,bool) and (double,bool,bool=false)
}

#include <iostream>
double charge(int grams)     { return grams; }
double charge(double kg)     { return kg; }
int main() { std::cout << charge(2L) << '\n'; }   // long -> int and long -> double are both conversions

#include <iostream>
#include <iomanip>

struct Parcel { double kg; bool express = false; bool insured = false; };

double charge(double kg, bool express = false, bool insured = false);   // defaults only here, once
double charge(int grams, bool express = false, bool insured = false);
double charge(const Parcel& p);

double charge(double kg, bool express, bool insured)
{
    std::cout << "[kg overload]     ";
    double c = 30 + 20 * kg;
    if (express) c += 40;
    if (insured) c += 15;
    return c;
}
double charge(int grams, bool express, bool insured)
{
    std::cout << "[grams overload]  ";
    double c = 30 + 20 * (grams / 1000.0);
    if (express) c += 40;
    if (insured) c += 15;
    return c;
}
double charge(const Parcel& p)
{
    std::cout << "[Parcel overload] ";
    double c = 30 + 20 * p.kg;
    if (p.express) c += 40;
    if (p.insured) c += 15;
    return c;
}

int main()
{
    std::cout << std::fixed << std::setprecision(2);
    Parcel p{3.0, true, false};
    std::cout << "1 charge(2)            = " << charge(2) << '\n';
    std::cout << "2 charge(2.0f)         = " << charge(2.0f) << '\n';
    std::cout << "3 charge(2.5)          = " << charge(2.5) << '\n';
    std::cout << "4 charge(500, true)    = " << charge(500, true) << '\n';
    std::cout << "5 charge(1.5,true,true)= " << charge(1.5, true, true) << '\n';
    std::cout << "6 charge(parcel)       = " << charge(p) << '\n';
}

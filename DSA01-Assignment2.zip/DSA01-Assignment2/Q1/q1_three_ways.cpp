#include <iostream>

struct Student { char name[64]; long long fee; char address[200]; int marks[50]; };

void applyByValue(long long fee, int p)  { fee -= fee * p / 100; std::cout << "  inside (value)   : " << fee << '\n'; }
void applyByRef(long long& fee, int p)   { fee -= fee * p / 100; std::cout << "  inside (ref)     : " << fee << '\n'; }
void applyByPtr(long long* fee, int p)   { if (fee) { *fee -= *fee * p / 100; std::cout << "  inside (pointer) : " << *fee << '\n'; } }
long long applyReturn(long long fee, int p) { return fee - fee * p / 100; }

long long feeOf(const Student& s) { return s.fee; }   // const ref: no copy, no modification

int main()
{
    long long fee = 45000;
    std::cout << "start " << fee << "\n";
    std::cout << "merit 10% by value:\n";   applyByValue(fee, 10); std::cout << "  stored fee: " << fee << '\n';
    std::cout << "merit 10% by ref:\n";     applyByRef(fee, 10);   std::cout << "  stored fee: " << fee << '\n';
    std::cout << "sports 15% by pointer:\n"; applyByPtr(&fee, 15);  std::cout << "  stored fee: " << fee << '\n';

    long long chained = applyReturn(applyReturn(45000, 10), 15);
    std::cout << "returning version, 10% then 15%: " << chained << '\n';

    Student s{"Asha", 45000, "", {}};
    std::cout << "sizeof(long long)=" << sizeof(long long)
              << "  sizeof(Student)=" << sizeof(Student)
              << "  sizeof(pointer/reference as implemented)=" << sizeof(void*) << '\n';
    std::cout << "feeOf(const Student&) = " << feeOf(s) << '\n';
}

#include <iostream>

class Time {
    int h, m;

public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    friend int minutesBetween(const Time& a, const Time& b);
    friend bool earlier(const Time& a, const Time& b);
};

int minutesBetween(const Time& a, const Time& b)
{
    int d = (a.h * 60 + a.m) - (b.h * 60 + b.m);   // TODO 1
    return d < 0 ? -d : d;
}

bool earlier(const Time& a, const Time& b)
{
    return a.h < b.h || (a.h == b.h && a.m < b.m); // TODO 2
}

void test(const char* label, Time a, Time b)
{
    std::cout << label << ": minutesBetween=" << minutesBetween(a, b)
              << " earlier(a,b)=" << std::boolalpha << earlier(a, b)
              << " earlier(b,a)=" << earlier(b, a) << '\n';
}
int main()
{
    test("11:50 vs 12:10 (across noon)", Time(11, 50), Time(12, 10));
    test("12:10 vs 11:50 (reversed)    ", Time(12, 10), Time(11, 50));
    test("09:45 vs 09:45 (same time)   ", Time(9, 45), Time(9, 45));
    test("00:00 vs 23:59 (extremes)    ", Time(0, 0), Time(23, 59));
    test("12:00 vs 12:00 (noon)        ", Time(12, 0), Time(12, 0));
}

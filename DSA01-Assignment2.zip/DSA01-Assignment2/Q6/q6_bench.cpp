#include <iostream>
#include <chrono>

class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    int getH() const { return h; }
    int getM() const { return m; }
    int minutesTo(const Time& o) const { int d = (o.h * 60 + o.m) - (h * 60 + m); return d < 0 ? -d : d; }
    friend int minutesInline(const Time& a, const Time& b);
    friend int minutesNoInline(const Time& a, const Time& b);
};
inline int minutesInline(const Time& a, const Time& b) { int d = (a.h * 60 + a.m) - (b.h * 60 + b.m); return d < 0 ? -d : d; }
__attribute__((noinline)) int minutesNoInline(const Time& a, const Time& b) { int d = (a.h * 60 + a.m) - (b.h * 60 + b.m); return d < 0 ? -d : d; }
int minutesGetters(const Time& a, const Time& b) { int d = (a.getH() * 60 + a.getM()) - (b.getH() * 60 + b.getM()); return d < 0 ? -d : d; }

template <class F> void bench(const char* name, F f)
{
    const int N = 10000000;
    long long sum = 0;
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < N; ++i) sum += f(Time(i % 24, i % 60), Time((i * 7) % 24, (i * 13) % 60));
    auto t1 = std::chrono::steady_clock::now();
    std::cout << name << ": " << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms (sum " << sum << ")\n";
}
int main()
{
    bench("friend, inline        ", [](const Time& a, const Time& b) { return minutesInline(a, b); });
    bench("friend, noinline      ", [](const Time& a, const Time& b) { return minutesNoInline(a, b); });
    bench("member minutesTo      ", [](const Time& a, const Time& b) { return a.minutesTo(b); });
    bench("non-friend + getters  ", [](const Time& a, const Time& b) { return minutesGetters(a, b); });
}

#include <iostream>
#include <chrono>
#ifndef TXN_CAP
#define TXN_CAP 10
#endif

struct Transaction { char type; long long amount; };

class SavingsAccount {
    long long accNo;
    long long balance;
    Transaction txn[TXN_CAP];          // private: only record() may keep the order/count rules
    int count;
    void record(char t, long long a);
public:
    static const int CAP = TXN_CAP;
    SavingsAccount(long long no, long long open = 0) : accNo(no), balance(open), count(0) {}   // defined inside
    long long getBalance() const { return balance; }                                          // defined inside
    void deposit(long long amt);                                                              // defined outside
    bool withdraw(long long amt);
    void miniStatement() const;
    long long checksum() const;
};

void SavingsAccount::record(char t, long long a)
{
    if (count == CAP) {                                   // 11th transaction: shift everything left
        for (int i = 0; i < CAP - 1; ++i) txn[i] = txn[i + 1];
        txn[CAP - 1] = {t, a};
    } else {
        txn[count++] = {t, a};
    }
}
void SavingsAccount::deposit(long long amt) { balance += amt; record('D', amt); }
bool SavingsAccount::withdraw(long long amt)
{
    if (amt > balance) return false;
    balance -= amt; record('W', amt); return true;
}
void SavingsAccount::miniStatement() const
{
    std::cout << "Mini-statement for A/C " << accNo << " (oldest first)\n";
    for (int i = 0; i < count; ++i)
        std::cout << "  " << (txn[i].type == 'D' ? "Deposit  " : "Withdraw ") << txn[i].amount << '\n';
    std::cout << "  Balance: " << balance << '\n';
}
long long SavingsAccount::checksum() const
{
    long long s = 0;
    for (int i = 0; i < count; ++i) s = s * 31 + txn[i].amount + txn[i].type;
    return s;
}

#ifdef BENCH
int main()
{
    const long long N = 1000000;
    SavingsAccount a(1, 0);
    auto t0 = std::chrono::steady_clock::now();
    for (long long i = 1; i <= N; ++i) a.deposit(i % 97 + 1);
    auto t1 = std::chrono::steady_clock::now();
    double ns = std::chrono::duration<double, std::nano>(t1 - t0).count() / N;
    std::cout << "SHIFT    CAP=" << SavingsAccount::CAP << "  " << ns << " ns/deposit  (checksum " << a.checksum() << ")\n";
}
#else
int main()
{
    SavingsAccount a(1001, 1000);
    for (int i = 1; i <= 12; ++i) {
        if (i % 3 == 0) { if (!a.withdraw(50 * i)) std::cout << "withdrawal " << 50 * i << " refused\n"; }
        else a.deposit(100 * i);
    }
    a.miniStatement();
}
#endif

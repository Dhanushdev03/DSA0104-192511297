# DSA01-<RegisterNumber>-Assignment2

- Name: <your name>        Register number: <your register number>
- Compiler: g++ 13.3.0 (Ubuntu 24.04)
- Compile command: `g++ -std=c++17 -Wall -Wextra QX/file.cpp -o file`  (Q4/Q7 benchmark: add `-O2 -DBENCH -DTXN_CAP=<n>`; Q6 benchmark: `-O0` and `-O2`)
- Run: `./file`
- One folder per task (Q1 ... Q7). Full report with predictions, explanations and measurements: `Report.md`. Raw run log: `logs/all_runs.txt`.

| Task | Result |
|---|---|
| Q1 | By value leaves fee 45000; reference and pointer give 40500; Complete-the-Code matches expected output |
| Q2 | highest() works as lvalue; dangling reference warns (-Wreturn-local-addr) and crashes; vector growth moves elements |
| Q3 | Original design is ambiguous; redesign compiles, all six calls select the predicted overload |
| Q4 | Shifting array keeps last 10 transactions correctly |
| Q5 | Static seat counter; output matches expected; count is not decreased when objects die |
| Q6 | `205 false`; tests across noon, equal times and extremes pass |
| Q7 | Circular buffer redesign of Q4: identical output, 28x faster at CAP=1000 |

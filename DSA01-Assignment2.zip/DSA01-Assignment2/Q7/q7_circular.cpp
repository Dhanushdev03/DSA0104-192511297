#include <iostream>
#include <chrono>
#ifndef TXN_CAP
#define TXN_CAP 10
#endif

struct Transaction { char type; long long amount; };

class SavingsAccount {
    long long accNo;
    long long balance;
    Transaction txn[TXN_CAP];
    int count;
    int start;                         // index of the oldest transaction
    void record(char t, long long a);
public:
    static const int CAP = TXN_CAP;
    SavingsAccount(long long no, long long open = 0) : accNo(no), balance(open), count(0), start(0) {}
    long long getBalance() const { return balance; }
    void deposit(long long amt);
    bool withdraw(long long amt);
    void miniStatement() const;
    long long checksum() const;
};

void SavingsAccount::record(char t, long long a)
{
    if (count < CAP) {
        txn[(start + count) % CAP] = {t, a};
        ++count;
    } else {                           // full: overwrite the oldest, advance start -> O(1)
        txn[start] = {t, a};
        start = (start + 1) % CAP;
    }
}
void SavingsAccount::deposit(long long amt) { balance += amt; record('D', amt); }
bool SavingsAccount::withdraw(long long amt)
{
    if (amt > balance) return false;
    balance -= amt; record('W', amt); return true;
}
void SavingsAccount::miniStatement() const
{
    std::cout << "Mini-statement for A/C " << accNo << " (oldest first)\n";
    for (int k = 0; k < count; ++k) {
        const Transaction& t = txn[(start + k) % CAP];
        std::cout << "  " << (t.type == 'D' ? "Deposit  " : "Withdraw ") << t.amount << '\n';
    }
    std::cout << "  Balance: " << balance << '\n';
}
long long SavingsAccount::checksum() const
{
    long long s = 0;
    for (int k = 0; k < count; ++k) { const Transaction& t = txn[(start + k) % CAP]; s = s * 31 + t.amount + t.type; }
    return s;
}

#ifdef BENCH
int main()
{
    const long long N = 1000000;
    SavingsAccount a(1, 0);
    auto t0 = std::chrono::steady_clock::now();
    for (long long i = 1; i <= N; ++i) a.deposit(i % 97 + 1);
    auto t1 = std::chrono::steady_clock::now();
    double ns = std::chrono::duration<double, std::nano>(t1 - t0).count() / N;
    std::cout << "CIRCULAR CAP=" << SavingsAccount::CAP << "  " << ns << " ns/deposit  (checksum " << a.checksum() << ")\n";
}
#else
int main()
{
    SavingsAccount a(1001, 1000);
    for (int i = 1; i <= 12; ++i) {
        if (i % 3 == 0) { if (!a.withdraw(50 * i)) std::cout << "withdrawal " << 50 * i << " refused\n"; }
        else a.deposit(100 * i);
    }
    a.miniStatement();
}
#endif
